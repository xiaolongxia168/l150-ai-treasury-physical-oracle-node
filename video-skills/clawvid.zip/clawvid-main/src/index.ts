#!/usr/bin/env node
import { program } from './cli/program.js';

program.parse(process.argv);
